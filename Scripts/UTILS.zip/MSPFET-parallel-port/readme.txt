MSPFET - MSP430 Flash Programming Utility
version: 1.46b

Copy "msp430.dll" and "hil.dll" from "$(IARPATH)\430\bin" to programm folder.


