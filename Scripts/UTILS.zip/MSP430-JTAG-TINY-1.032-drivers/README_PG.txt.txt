1. Plug in MSP-JTAG-TINY to the computer
2. When prompted for drivers, point the system to Drivers in this directory
3. Move the contents of DLLs to .../mspgcc/bin (the same directory that gdbproxy is in)