	---------------------------------------------------------
	---- README.TXT -----------------------------------------
	---------------------------------------------------------

	---------------------------------------------------------
	---- Routing Tags v. 1.0 --------------------------------
	---- Copyright by Olsonet Communications Corporation ----
	---- Sep 08, 2005 ---------------------------------------
	---------------------------------------------------------

---------------------------
--- General information ---
---------------------------

The main window consists of three parts:

- Selection Panel
A user can select various options, effectively building an instruction
packet. The packet is sent when "Send" is clicked.

- Message Window
This (middle) window displays received responses.

- Debug Window
This window displays various auxiliary messages.

Message formats and many other details related to this application are
in "RTags Command Set" document.

-----------------------------------------
--- Format of the configuration file  ---
-----------------------------------------

Configuration file 'configRoutingTags' has several parameters:

* DebugLevel

This parameter can have two values: 0 or 1. If set to 0, the
application displays bytes received outside of a packet in the Message
Window. If set to 1, the application does not display these bytes.

* PortName
* BaudRate
* Parity
* DataBits
* StopBits

These parameters define a connection via a serial port.

* Remaining parameters

See "RTags Command Set" document for details on the meaning of these
parameters.
