#ifndef __app_node_data_h__
#define	__app_node_data_h__

__STATIC int		SFD;
__STATIC lcdg_dm_obj_t	*objects [MAXOBJECTS];
__STATIC char		*ibuf __sinit (NULL);

#endif
