#ifndef __vuee_h__
#define	__vuee_h__

#ifdef __SMURPH__

#include "node.h"

#include "stdattr.h"

#endif
#endif
