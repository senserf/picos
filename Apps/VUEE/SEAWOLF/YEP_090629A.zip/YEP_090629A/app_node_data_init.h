
for (int i = 0; i < MAXOBJECTS; i++)
	objects [i] = NULL;

ibuf = NULL;

