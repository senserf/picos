#ifndef __app_types_h__
#define __app_types_h__

#define	MAXLINES	32
#define	MAXOBJECTS	32

#define	NPVALUES	12
#define	LABSIZE		(LCDG_IM_LABLEN+2)

#endif
