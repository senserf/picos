#ifndef	__app_root_static_h__
#define	__app_root_static_h__
//
// The static variables of app.c's root

    __STATIC word c [NPVALUES];
    __STATIC byte Status;
    __STATIC char lbl [LABSIZE];
    __STATIC char **lines;
    __STATIC lcdg_im_hdr_t *isig;

#endif
