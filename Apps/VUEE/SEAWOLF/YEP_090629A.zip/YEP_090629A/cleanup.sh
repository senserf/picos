#!/bin/sh
cd PICTURES
rm -rf *.nok
cd ../FONTS
rm -rf *.nok
cd ..
rm -rf *.nok
rm -rf dump.txt
