// for host_id auto-generation

#ifndef __SMURPH__
#include "sysio.h"
const lword host_id = 0xBACA0002;
#endif

