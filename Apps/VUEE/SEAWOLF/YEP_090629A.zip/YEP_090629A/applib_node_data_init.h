
host_id = (lword) preinit ("HID");
