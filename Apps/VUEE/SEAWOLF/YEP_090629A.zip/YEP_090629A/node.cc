#include "vuee.h"

void SeaNode::init () {

// ============================================================================

#include "app_node_data_init.h"
#include "applib_node_data_init.h"
#include "msg_node_data_init.h"

// ============================================================================

	// Start application root
	appStart ();
}
